const posi = ["good","excellent","adequate","outstanding","Marvellous","Pleasing"]
  const neg = ["bad","worst","bad"]
  function myFunction() {
    console.log("testing gooding")

   let input_text = document.getElementById("message-e4cc").value;
    if (posi.some(v => input_text.includes(v))) {
      alert("This is positive");}
      else if(neg.some(v => input_text.includes(v))){
        alert("This is Negative");

      }else {alert ("netural")}

  }
  document.getElementById("submit").addEventListener("click",myFunction)
