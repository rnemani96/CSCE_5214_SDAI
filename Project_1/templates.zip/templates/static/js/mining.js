const posi = ["good","excellent","adequate","outstanding","Marvellous","Pleasing","commonsense", "commonsensible", "commonsensical", "firm", "hard", "informed", "just", "justified", "levelheaded", "logical", "rational",
 "reasonable", "reasoned", "sensible", "sober", "solid", "valid", "well-founded"]
  const neg = ["bad","worst","bad","frustrating experience","troubles","trouble","unpleasant", "not good","horrible","negative","bastard",
"lame","poor","punk","dissatisfactory","ill"," lousy","deficient","unacceptable"," unsatisfactory","not satisfied","notsatisfied","unabletoaccept",
"frustrating-experience","wrong","awful","terrible", "unspeakable","horrendous"," horrible", "pathetic", "stinky","disastrous", "dreadful", "execrable",
"brutal", "damnable", "deplorable", "detestable","defective", "faulty", "flawed","low-grade", "low-rent", "mediocre", "miserable", "reprehensible", "rotten", "rubbishy", "second-rate",
 "shoddy", "sleazy", "trashy","useless", "valueless", "worthless"]
  function myFunction() {
    console.log("testing gooding")

   let input_text = document.getElementById("message-e4cc").value;
    if (posi.some(v => input_text.includes(v))) {
      alert("This is positive");}
      else if(neg.some(v => input_text.includes(v))){
        alert("This is Negative");

      }else {alert ("Neutral")}

  }
  document.getElementById("submit").addEventListener("click",myFunction)
